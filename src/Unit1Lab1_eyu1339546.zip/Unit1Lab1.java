/**
 * This class/program prints shapes
 * @author Ethan Yu
 */
public class Unit1Lab1 {
    public static void main(String[] args) {
        System.out.println("*********        ***           *          * ");
        System.out.println("*       *     *       *       ***        * *");
        System.out.println("*       *   *           *    *****      *   *");
        System.out.println("*       *   *           *      *       *     *");
        System.out.println("*       *   *           *      *      *       *");
        System.out.println("*       *   *           *      *       *     *");
        System.out.println("*       *   *           *      *        *   *");
        System.out.println("*       *     *       *        *         * *");
        System.out.println("*       *        ***           *          *");
    }
}
